// Render the generated HTML to PDF with headless Chromium, then stamp document metadata.
// Usage: NODE_PATH=<global node_modules> node render.mjs [outDir]
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const { PDFDocument } = require('pdf-lib');

const here = dirname(fileURLToPath(import.meta.url));
const out = resolve(process.argv[2] || resolve(here, 'out'));
mkdirSync(out, { recursive: true });

const KEYWORDS = ['Means+Measures', 'UEI TMUKBK9UY3H2', 'CAGE 21XA2', 'Veteran-Owned Small Business'];
const DOCS = {
  'Means-Measures-Capability-Statement': { title: 'Means+Measures — Capability Statement', subject: 'Capability statement' },
  'Means-Measures-Principal-Bio': { title: 'Means+Measures — Principal Bio', subject: 'Principal · key personnel — capability and experience of record' },
  'Means-Measures-Capability-Packet': { title: 'Means+Measures — Capability Packet', subject: 'Principal-led institutional coherency practice — capability packet' },
  'MeansMeasuresCapabilityPacket': { title: 'Means+Measures — Capability Packet', subject: 'Principal-led institutional coherency practice — capability packet' },
};

const browser = await chromium.launch(process.env.MM_CHROMIUM_PATH ? { executablePath: process.env.MM_CHROMIUM_PATH } : {});
let bad = 0;
for (const [name, meta] of Object.entries(DOCS)) {
  const page = await browser.newPage();
  await page.goto(pathToFileURL(resolve(here, name + '.html')).href, { waitUntil: 'load' });
  await page.evaluate(() => document.fonts.ready);
  // Layout guard: content must end above the footer on every page, and every face must have loaded.
  const report = await page.evaluate(() => {
    const pages = [...document.querySelectorAll('.page')].map((p, i) => {
      const b = p.querySelector('.body').getBoundingClientRect();
      const f = p.querySelector('.foot').getBoundingClientRect();
      let w = 0;
      p.querySelectorAll('*').forEach(e => { const r = e.getBoundingClientRect(); if (r.right > p.getBoundingClientRect().right - 40) w++; });
      return { page: i + 1, slackPt: Math.round((f.top - b.bottom) * 0.75 * 10) / 10, wideEls: w };
    });
    const failed = [...document.fonts].filter(f => f.status === 'error').map(f => f.family + ' ' + f.weight + ' ' + f.style);
    const used = [...new Set([...document.fonts].filter(f => f.status === 'loaded').map(f => f.family))];
    return { pages, failed, used };
  });
  for (const p of report.pages) if (p.slackPt < 3 || p.wideEls) { bad++; }
  if (report.failed.length) bad += report.failed.length;
  console.log(name, JSON.stringify(report.pages), 'fonts:', report.used.join(', '), report.failed.length ? 'FAILED ' + report.failed : '');
  const bytes = await page.pdf({ preferCSSPageSize: true, printBackground: true, tagged: true, outline: true });
  await page.close();
  const pdf = await PDFDocument.load(bytes, { updateMetadata: false });
  pdf.setTitle(meta.title, { showInWindowTitleBar: true });
  pdf.setAuthor('Means and Measures LLC');
  pdf.setSubject(meta.subject);
  pdf.setKeywords(KEYWORDS);
  pdf.setLanguage('en-US');
  writeFileSync(resolve(out, name + '.pdf'), await pdf.save());
}
await browser.close();
if (bad) { console.error(`LAYOUT: ${bad} page(s) overflow or run wide`); process.exit(2); }
