"""Populate ./fonts/ with the exact filenames means-measures.fonts.css expects.
Source: @fontsource packages (OFL), latin subsets, converted woff2 -> woff."""
import re, os
from fontTools.ttLib import TTFont
nm='node_modules/'
W={'extralight':200,'light':300,'regular':400,'medium':500,'semibold':600,'bold':700,'extrabold':800}
m={}
m['bodoni-moda.woff']=nm+'@fontsource-variable/bodoni-moda/files/bodoni-moda-latin-opsz-normal.woff2'
m['bodoni-moda-italic.woff']=nm+'@fontsource-variable/bodoni-moda/files/bodoni-moda-latin-opsz-italic.woff2'
m['bodoni-moda-sc.woff']=nm+'@fontsource-variable/bodoni-moda-sc/files/bodoni-moda-sc-latin-opsz-normal.woff2'
m['bodoni-moda-sc-italic.woff']=nm+'@fontsource-variable/bodoni-moda-sc/files/bodoni-moda-sc-latin-opsz-italic.woff2'
m['montserrat.woff']=nm+'@fontsource-variable/montserrat/files/montserrat-latin-wght-normal.woff2'
m['montserrat-italic.woff']=nm+'@fontsource-variable/montserrat/files/montserrat-latin-wght-italic.woff2'
m['metrophobic.woff']=nm+'@fontsource/metrophobic/files/metrophobic-latin-400-normal.woff2'
m['pompiere.woff']=nm+'@fontsource/pompiere/files/pompiere-latin-400-normal.woff2'
for fam,pk in (('spectral','spectral'),('spectralsc','spectral-sc')):
    for k,w in W.items():
        m[f'{fam}-{k}.woff']=nm+f'@fontsource/{pk}/files/{pk}-latin-{w}-normal.woff2'
        it = 'italic' if k=='regular' else k+'italic'
        m[f'{fam}-{it}.woff']=nm+f'@fontsource/{pk}/files/{pk}-latin-{w}-italic.woff2'
for k,(w,s) in {'regular':(400,'normal'),'italic':(400,'italic'),'bold':(700,'normal'),'bolditalic':(700,'italic')}.items():
    m[f'iosevka-{k}.woff']=nm+f'@fontsource/iosevka/files/iosevka-latin-{w}-{s}.woff2'
need=set(re.findall(r'\./fonts/([\w.-]+)', open('means-measures.fonts.css').read()))
print('css expects',len(need),'mapped',len(m),'missing:',need-set(m),'extra:',set(m)-need)
os.makedirs('fonts',exist_ok=True)
for out,src in m.items():
    f=TTFont(src); f.flavor='woff'; f.save('fonts/'+out)
f=TTFont('fonts/bodoni-moda.woff'); print([ (a.axisTag,a.minValue,a.maxValue) for a in f['fvar'].axes])
names=['spectral-regular.woff','iosevka-regular.woff','montserrat.woff','bodoni-moda.woff','bodoni-moda-sc.woff','metrophobic.woff','pompiere.woff','spectralsc-regular.woff']
cm={n:TTFont('fonts/'+n).getBestCmap() for n in names}
for ch in '↔☐×·—–’“”~&§+→':
    print(ch, hex(ord(ch)), ''.join('Y' if ord(ch) in cm[n] else '-' for n in names))
