#!/usr/bin/env python3
"""Means+Measures capability documents — HTML source generator.

Writes four HTML files that render.mjs prints to PDF with headless Chromium.
Identity-bound values live in ID below; change one line there and re-run to
update every document.
"""
import html, re, pathlib

# --------------------------------------------------------------------------
# Identity — single point of change
# --------------------------------------------------------------------------
ID = dict(
    name="Means+Measures",
    legal="Means and Measures LLC",
    formerly="",   # no legacy names; a value here restores a "formerly" line everywhere
    site="meansandmeasures.com",
    email="procurement@meansandmeasures.com",
    phone="816-306-3481",
    thesis=("Down through systems.", "Up through people."),
    commons="For the Commons",
    practice="institutional coherency practice",  # was: "institutional interfacing practice"
    forecast_repo="",   # repo sits under a legacy org name; left off until it moves
)
N = ID["name"]
IDS_FULL = "UEI TMUKBK9UY3H2 · CAGE 21XA2 · EIN 39-2829761 · Veteran-Owned Small Business"


def fmt(s):
    s = html.escape(s, quote=False)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"\*(.+?)\*", r"<i>\1</i>", s)
    s = s.replace("&lt;-&gt;", '<span class="arr">↔</span>')
    return s


def link(url):
    return f'<a class="mm-link" href="https://{url}">{url}</a>'


def foot(left):
    return (f'<footer class="foot"><span class="ids">{fmt(left)}</span>'
            f'<span class="commons">{fmt(ID["commons"])}</span></footer>')


def sh(title, note=""):
    n = f' <span class="note">{fmt(note)}</span>' if note else ""
    return f'<h2 class="sh"><span>{fmt(title)}</span>{n}</h2>'


def panel(title, inner, cls=""):
    return f'<section class="panel {cls}"><h2>{fmt(title)}</h2>{inner}</section>'


def kv(rows, cls=""):
    out = [f'<table class="kv {cls}">']
    for k, v, *em in rows:
        c = ' class="em"' if em else ""
        out.append(f'<tr><th scope="row">{fmt(k)}</th><td{c}>{v}</td></tr>')
    out.append("</table>")
    return "".join(out)


def thesis():
    a, b = ID["thesis"]
    return f'<p class="thesis"><span>{fmt(a)}</span><span>{fmt(b)}</span></p>'


def lockup():
    return ('<img class="mm-logo" src="logo-lockup.png" '
            f'alt="{N} logo: interlocking joinery mark with a central plus, above the {N} wordmark">')


def rh(label, sub):
    return (f'<header class="rh"><div class="markbox"><img class="mm-logo" src="logo-mark.png" alt="{N} mark"></div>'
            f'<div class="lbl"><div class="k">{fmt(label)}</div><div class="s">{fmt(sub)}</div></div></header>')


def page(inner, footer, cls=""):
    return f'<section class="page {cls}"><div class="body">{inner}</div>{footer}</section>'


# --------------------------------------------------------------------------
# Shared sidebar blocks
# --------------------------------------------------------------------------
NAICS = ('<div class="codes"><p><b>541690</b> (primary NAICS)<br>518210 · 541511 · 541512 · 541611 ·<br>541618 · 541720 · 813410</p>'
         '<p>R617 · R702 · B510 · B529 · DA01 · DF01 ·<br>R408 · R425 · R499 · R699 · AJ12 · U004</p></div>')

WONT = ("A published line, not a sales promise: no surveillance, predictive policing, discriminatory screening, "
        "dark-pattern intake, or systems that make vulnerable people easier to punish. You know the limits before "
        "you sign — and so does every partner we bring.")


def entity_rows(packet):
    rows = [("Legal", fmt(ID["legal"]))]
    if ID["formerly"]:
        rows.append(("Formerly", fmt(ID["formerly"])))
    rows += [("Type", "Missouri LLC · for-profit"), ("UEI", "TMUKBK9UY3H2")]
    if packet:
        rows.append(("CAGE", "21XA2"))
    rows += [("EIN", "39-2829761"), ("SAM", "For-Profit · LLC · Sole Prop")]
    if packet:
        rows.append(("Socio-ec", "Veteran-Owned Small Business", True))
    rows.append(("Base", "Kansas City, Missouri"))
    return rows


def contact_panel(web):
    return panel("Contact", kv([("Email", f'<a href="mailto:{ID["email"]}">{ID["email"]}</a>'),
                                ("Phone", ID["phone"]), ("Web", link(web))], "contact"))


def clearance(v, n):
    return panel("Security Clearance", f'<p class="v">{fmt(v)}</p><p class="n">{fmt(n)}</p>', "clr")


DELIVERABLES = ["Resource directories & navigation hubs", "AI governance frameworks & policies",
                "Records review & sufficiency packages", "Process maps & system documentation",
                "Public data portals & open-data exports", "Public comment packages & filings",
                "Data dictionaries & provenance models", "Procurement & acquisition support docs"]


def runin(items, cls=""):
    return f'<ul class="sq {cls}">' + "".join(f"<li>{fmt(i)}</li>" for i in items) + "</ul>"


def projects(items):
    li = "".join(f'<li><span class="t">{fmt(t)}</span><span class="d">{fmt(d)}</span></li>' for t, d in items)
    return f'<ul class="sq proj">{li}</ul>'


# --------------------------------------------------------------------------
# Page 1 — capability statement (three copy generations)
# --------------------------------------------------------------------------
def statement_page(v):
    packet = v in ("jul", "aug")
    if v == "solo":
        lead = (f'<p class="lead">{fmt(N + " designs **public information systems**, **records-review workflows**, and "
                "**AI-governance infrastructure** for government, nonprofit, and civic-sector organizations.")}</p>'
                f'<p class="sub">{fmt("Systems that keep responsibility, provenance, and decision-making visible — clear enough to understand, strong enough to stand behind, and legible enough that agency stays attached to the people inside them.")}</p>')
    elif v == "jul":
        lead = (f'<p class="lead">{fmt(N + " is a **principal-led " + ID["practice"] + "** — designing the points where people, institutions, software, and oversight meet, and fixing them when they fail.")}</p>'
                f'<p class="sub">{fmt("You work with the principal who does the work. Specialists join when an engagement needs a discipline we don’t hold — but every engagement is architected around a single coherent operational model. No account layering, no department seams for the work to fall through.")}</p>')
    else:
        lead = f'<p class="lead">{fmt(N + " builds, audits, and fixes the mechanics of public institutions. We deliver fixed-scope solutions to boundaries where people need access, software demands governance, decisions mandate oversight, and internal processes struggle against preservation. You work directly with the principal who does the work, ensuring diagnosis and execution happen in the same head.")}</p>'

    if v == "solo":
        first = sh("Core Capabilities") + runin([
            "**Civic Information Infrastructure** — resource directories, public data surfaces, multilingual navigation, correction workflows, confidence-tiered records, and machine-readable exports.",
            "**Records & Review Systems** — record-sufficiency review, public-comment preparation, procurement packets, and public-record organization.",
            "**AI Governance & Provenance** — governed agent-memory patterns, provenance review, stop-lifecycle design, and practical controls for AI-mediated workflows.",
            "**Observational Data Systems** — source-faithful ingestion, temporal and geographic integrity, and provenance-preserving data models.",
            "**Plain-Language Institutional Interfaces** — accessibility-forward intake forms, guidance pages, process maps, and public notices."])
    else:
        sep = " <-> " if v == "jul" else " : "
        note = ("Different-looking problems are usually the same phenomenon at a different boundary. We diagnose by interface, then build to it."
                if v == "jul" else
                "Different-looking problems are often the same phenomenon at different boundaries. We diagnose by interface, then build to suit the relationships at hand.")
        rows = [("Human", "Institution", "When a person needs to find, understand, or get through a system.",
                 "Resource directories · multilingual navigation · plain-language interfaces · accessibility-forward intake · confidence-tiered records"),
                ("Institution", "Software", "When automated systems act inside an institution and accountability has to survive the automation.",
                 "AI-governance frameworks · governed agent memory · provenance review · stop-lifecycle design · source-faithful data models"),
                ("Institution", "Oversight", "When a decision has to be reconstructable by someone who wasn’t in the room.",
                 "Record-sufficiency review · decision traceability · public-comment preparation · procurement documentation"),
                ("Institution", "Itself", "When an institution can’t see its own operation — process in someone’s head, records in a heap.",
                 "Process mapping · knowledge preservation · records organization · modernization assessment")]
        li = "".join(f'<li><span class="h">{fmt(a + sep + b)}</span><span class="w">{fmt(w)}</span><span class="i">{fmt(i)}</span></li>'
                     for a, b, w, i in rows)
        first = sh("The Interface Map") + f'<p class="small dim" style="font-style:italic;margin:-1pt 0 5pt">{fmt(note)}</p><ul class="sq imap">{li}</ul>'

    deliv = sh("Representative Deliverables") + '<div class="two">' + "".join(
        runin(DELIVERABLES[i::2], "tight") for i in (0, 1)) + "</div>"

    diffs = ["**Document-forward and static-first** — deliverables are inspectable, citable, and durable; not locked behind a dashboard or login.",
             "**A published boundary** — explicit ethical exclusions and a record-sufficiency standard let a reviewer know in advance what we will and will not build.",
             "**An operating instrument already in the field** — a bi-state public-resource directory covering all nine MARC counties, with daily exports and a five-tier confidence model."]
    if packet:
        diffs.insert(0, "**One coherent operational model** — diagnosis and build happen in the same head; nothing is lost in translation. Size is the feature, not the caveat.")
    diff = sh("Differentiators") + runin(diffs)

    kc = "Regional civic-information infrastructure covering all nine MARC counties, with daily machine-readable exports and confidence-tiered records."
    fc = "Provenance-preserving observational data platform built for temporal integrity and source fidelity."
    fed = "Multi-register submissions to federal rulemaking emphasizing record sufficiency, traceability, and public accountability."
    if v == "aug":
        kc += " Served 45,000 unique visitors over first 3 months in a 2.4 million-person metro."
        fc += " Integrates realtime METAR translations into operational outlooks."
        fed = "Multi-register submissions to federal rulemaking on record sufficiency, traceability, and public accountability."
    proj = sh("Selected Projects") + projects([
        ("KC Metro Resource Directory", kc), ("Forecast", fc),
        ("OpenCognition", "Reference implementation of governed AI memory, provenance review, and agent-lifecycle controls."),
        ("Federal Public-Record Comments", fed)])

    if packet:
        why = ("A principal-led practice, deliberately. The diagnosis and the build happen in the same head, so you get senior output at a fraction "
               "of a multistate firm’s cost — without the account layer, the markup, or the half-product assembled by whoever was on the bench. "
               "Specialists join when an engagement needs a discipline we don’t hold; the operational model stays singular.")
        clr = clearance("SECRET ELIGIBILITY", "Access inactive")
    else:
        why = ("You work directly with the principal who builds the work — not an account layer marking up junior staff. Inspectable, "
               "document-forward delivery and no enterprise overhead: senior output at a fraction of a multistate firm’s cost, with a published "
               "boundary so you know exactly what you’re buying. Built for work where the public record matters and accountability can’t be faked.")
        clr = clearance("SECRET", "Favorably adjudicated")

    side = (f'<div class="doclabel"><div class="k">Capability Statement</div><div class="u">{link(ID["site"])}</div></div>'
            + clr + panel("Entity", kv(entity_rows(packet))) + panel("NAICS & PSC Codes", NAICS)
            + panel("Why " + N, f"<p>{fmt(why)}</p>") + panel("What We Won’t Build", f"<p>{fmt(WONT)}</p>")
            + contact_panel(ID["site"] + "/procurement"))
    main = (f'<header class="mast">{lockup()}{thesis()}</header><hr class="rule">' + lead + first + deliv + diff + proj)
    if packet:
        f = foot(IDS_FULL)
    else:
        f = foot(ID["legal"] + (" · formerly " + ID["formerly"] if ID["formerly"] else ""))
    return page(f'<div class="cols"><main>{main}</main><aside>{side}</aside></div>', f, "p-statement v-" + v)


# --------------------------------------------------------------------------
# Page 2 — service catalog
# --------------------------------------------------------------------------
FAMS = [
    ("01", "Information Infrastructure", "Human <-> Institution",
     "When people need to find, use, or trust public information.",
     ["Public resource directories", "Data portals & open-data exports", "Information-architecture assessments",
      "Accessibility & plain-language reviews", "Community resource-ecosystem assessments"],
     "Structured service inventory · searchable public surface · data dictionary · CSV/JSON exports · maintenance documentation."),
    ("02", "Governance & Accountability", "Institution <-> Oversight · Institution <-> Software",
     "When a decision has to be traceable, contestable, or audit-ready.",
     ["Record-sufficiency reviews", "AI-governance reviews", "Decision-traceability frameworks",
      "Provenance & data-lineage assessments", "Procurement documentation support", "Public-comment & regulatory-review support"],
     "Assessment & gap analysis · risk findings · governance framework · human-review controls · executive summary."),
    ("03", "Institutional Operations", "Institution <-> Itself",
     "When the work lives in someone’s head, the process is opaque, or the records are a mess.",
     ["Process mapping & documentation", "Institutional knowledge preservation",
      "Civic-information modernization assessments", "Public-records organization"],
     "Current-state process maps · responsibility mapping · modernization roadmap · operational playbooks · audit-ready archive design."),
]


def catalog_page():
    fams = "".join(
        f'<section class="fam"><h2><span class="n">{n}</span><span>{fmt(t)}</span></h2><p class="rel">{fmt(r)}</p>'
        f'<p class="when">{fmt(w)}</p>{runin(items)}<div class="td"><div class="lab">Typical Deliverables</div><p>{fmt(td)}</p></div></section>'
        for n, t, r, w, items, td in FAMS)
    std = [("Fixed scope", "Agreed in writing before work begins. No scope creep, no surprise invoices."),
           ("Defined deliverables", "A named artifact list you can point to — not a vague “consulting engagement.”"),
           ("Visible acceptance criteria", "How “done” is judged, written down and shared up front."),
           ("Open & inspectable", "Machine-readable outputs in open formats; provenance preserved throughout.")]
    steps = [("01", "Interface diagnosed", "Which boundaries are in play"),
             ("02", "Scope & criteria agreed", "In writing, before any work begins."),
             ("03", "Build & deliver", "The named artifact list, nothing vague."),
             ("04", "Review against criteria", "Acceptance is measured, not argued."),
             ("05", "Accept & hand off", "With an optional maintenance retainer.")]
    tiles = ["Fixed-scope build", "Assessment / memorandum", "Maintenance retainer", "Per-item (comment, notice)", "Prime or subcontract"]
    inner = (rh("Service Catalog", "What you can buy")
             + '<h1 class="pt">Three acquisition families. <span class="a">Pick the problem, not a SKU.</span></h1>'
             + f'<p class="intro">{fmt("Each family is one region of the interface map, expressed in acquisition terms. Every engagement is a discrete, **fixed-scope package** — a defined deliverable set and **acceptance criteria agreed before work begins**, so “done” is never a matter of opinion. Machine-readable outputs ship in open formats by default, and any package can be scoped directly to your solicitation.")}</p>'
             + f'<div class="fams">{fams}</div>'
             + '<h2 class="bar">The Deliverable Standard — Every Package, No Exceptions</h2><div class="std">'
             + "".join(f'<div><div class="h">{fmt(h)}</div><p>{fmt(p)}</p></div>' for h, p in std) + "</div>"
             + '<h2 class="bar">Engagement Models</h2><div class="lab">Buy It As</div><div class="tiles">'
             + "".join(f"<div>{fmt(t)}</div>" for t in tiles) + "</div>"
             + '<h2 class="bar">How an Engagement Runs</h2><div class="steps">'
             + "".join(f'<div><div class="n">{n}</div><div class="h">{fmt(h)}</div><p>{fmt(p)}</p></div>' for n, h, p in steps) + "</div>"
             + f'<p class="note">{fmt("**Fifteen standard deliverable packages** sit beneath these three families, each with its own fixed scope, defined deliverable list, and acceptance-criteria checklist — see the attached appendix for full specifications, or scope directly against your solicitation’s statement of work.")}</p>')
    return page(inner, foot(IDS_FULL), "p-catalog")


# --------------------------------------------------------------------------
# Page 3 — selected projects
# --------------------------------------------------------------------------
def projects_page():
    s = ID["site"]
    P = [("KC Metro Resource Directory", "Live", "success",
          f'SOLE DEVELOPER &amp; OPERATOR · 2025–present · {link(s + "/kc")}',
          "People-first survival and navigation directory covering all nine MARC counties (five Missouri, four Kansas) across a metro of ~2.4M. Five-tier confidence model, plain-language access notes, Spanish localization, accessibility controls, and daily machine-readable exports (JSON/CSV/plain-text) free to mirror and redistribute. **More than 45,000 unique visitors since launch.**",
          ["Civic information infrastructure", "Multilingual navigation", "Confidence-tiered records", "Open-data publishing"]),
         ("Forecast", "Live", "success",
          f'SOLE DEVELOPER · {link("forecast." + s)}' + (f' · {link(ID["forecast_repo"])}' if ID["forecast_repo"] else ""),
          "Time-resolved, multi-source observational field infrastructure. Environmental and civic observations preserved with source fidelity, geographic resolution, and temporal integrity; custom data model built for downstream analysis without erasing provenance.",
          ["Observational data systems", "Provenance-preserving modeling", "Temporal integrity"]),
         ("OpenCognition", "Published", "info",
          f'SOLE AUTHOR / ARCHITECT · {link("github.com/bjl13/open-cognition")}',
          "Sole-authored reference substrate for governed agent memory: immutable canonical objects, scoped references, stop lifecycle, attributable state transitions, and accountable memory state.",
          ["AI governance & provenance", "Attributable state design"]),
         ("hkdf-derive", "Published · MIT", "info",
          f'SOLE AUTHOR · {link("github.com/bjl13/hkdf-derive-1.0.0")}',
          "Deterministic HKDF key-derivation utility with strict secret handling, an environment-aware correlation identifier, structured audit logging, systemd integration, and a documented migration playbook. Evidence of applied-cryptography and security rigor — an orchestration layer over OpenSSL primitives, not a FIPS-validated module.",
          ["Identity & trust infrastructure", "Security architecture"]),
         ("Federal Public-Record Comments", "Filed", "info",
          f'AUTHOR · USCIS biometrics (×3) &amp; NWK-408 · {link(s + "/artifacts")}',
          "Docket-ready public comments on USCIS biometrics policy in three registers (academic, civil-rights, professional) and a public-record comment on NWK-408. Hosted as durable, downloadable public artifacts.",
          ["Records & review systems", "Record-sufficiency analysis", "Multi-audience drafting"]),
         ("Record Sufficiency Matrix", "Published", "info",
          f'AUTHOR · {link(s + "/artifacts/record-sufficiency-matrix")}',
          "Analytical instrument for evaluating whether a system preserves enough record for affected stakeholders to understand, contest, and review consequential actions — applicable to public records, agency decisions, procurement materials, and AI-mediated summaries.",
          ["Methodological / evaluative", "Institutional analysis"])]
    pj = "".join(
        f'<article class="pj"><div class="top"><h2>{fmt(t)}</h2><span class="mm-status" data-mm-status="{st}">{fmt(tag.upper())}</span></div>'
        f'<p class="meta">{meta}</p><p class="d">{fmt(d)}</p><p class="tags">{fmt(" · ".join(tags))}</p></article>'
        for t, tag, st, meta, d, tags in P)
    inner = (rh("Selected Projects", "Evidence of delivered capability")
             + f'<p class="pintro">{fmt("**Every system below is real, built, and publicly inspectable** — operating infrastructure you can open in a browser right now, not slideware. Each one demonstrates delivered capability across civic information infrastructure, records and review, AI governance, and observational data.")}</p>'
             + f'<div class="pjs">{pj}</div>'
             + f'<p class="callout" style="margin-top:12pt">{fmt("**Open any link and inspect the work yourself** — that is the whole point. A lean shop delivering senior work directly, at a fraction of a multistate firm’s cost, with output you can audit instead of take on faith. References and engagement metrics on request.")}</p>')
    return page(inner, foot(IDS_FULL), "p-projects")


# --------------------------------------------------------------------------
# Principal bio (standalone generation + packet generation)
# --------------------------------------------------------------------------
CLINICAL = "Former Flight Medic, 10+ years EMS including critical-care and specialty transport — operating across rural, urban, correctional, military, and federal environments, from austere field medicine to quaternary-level care. State-level recognition through the Kansas EMS Association community."
MILITARY = "Officer, U.S. Navy Reserve; Health Professions Scholarship Program participant; military medical, operational, and interagency experience. Honorably discharged."
LEADERSHIP = "Regional leadership and policy-development roles in the American Medical Association; bylaws and governance-review contributor; published author of parliamentary-procedure educational resources."
AIRES = "Sole author of **OpenCognition**, a governed agent-memory substrate. Separately, an early community participant in the OpenCog ecosystem — a distinct project (participation, not authorship). Knowledge representation, cognitive architectures, and multi-agent provenance."
SPECIAL = "Epidemiology · Health policy · Emergency medicine · Systems theory · Organizational governance · Distributed systems · AI & cognitive architectures · Public-sector technology · Information provenance · Community resilience"


def bio_page(v):
    solo = v == "solo"
    role = f"Founder & Principal, {N}"
    if solo:
        summary = ("A systems operator whose career has run through emergency medicine, public health, military service, professional governance, and public-interest technology — and kept returning to the same problem underneath all of them: how complex institutions coordinate information, decisions, and people without coming apart. The rare principal who has worked both the consequence end of that problem as a flight medic and the structural end as an infrastructure builder, researcher, and governance contributor. "
                   + N + " is where those threads converge.")
        edu_l = ["**MPH** — Master of Public Health *(in progress)*",
                 "**MS** — Biomedical & Physical Sciences · Univ. of Kansas, 2025||Thesis: The Gospel of Metrics: Policy Capacity in Governmental Public Health Agencies",
                 "**BA** — French Language & Culture · Univ. of Kansas, 2015"]
        edu_r = ["**BA** — Applied Behavioral Science: Community Health & Development · Univ. of Kansas, 2015",
                 "**Preclinical Medicine** — completed MD-curriculum preclinical education (not a conferred MD)",
                 "**Instructorships** — AHA-certified ACLS · PALS · NRP · BLS",
                 "**Security clearance** — Secret, favorably adjudicated"]
        exp = [("Public Health & Research", "Population-health researcher in policy capacity, measurement, and systems-level intervention. Master’s thesis — *The Gospel of Metrics* — examined policy capacity and the politics of measurement inside governmental public-health agencies."),
               ("Clinical & Emergency Services", CLINICAL), ("Military Service", MILITARY),
               ("Professional Leadership & Governance", LEADERSHIP),
               ("Technology & Infrastructure", "Cloud-native infrastructure, automation, and identity-management systems; distributed systems, PKI, and security architecture. Sole author of **hkdf-derive** (published, MIT) — concrete evidence of the security-architecture work."),
               ("AI & Systems Research", AIRES)]
        tech = "Static-first web (Astro) · data-pipeline & schema/export design · multilingual content systems · accessibility · cloud-native infrastructure & automation · PKI / identity & trust · security architecture · AI-governance & agent-memory design"
        record = "USCIS biometrics comments ×3 · NWK-408 comment · *Abstraction Harm* · *Situated Inference* · Record Sufficiency Matrix"
        closing = "The same instinct runs through all of it — clinical, military, civic, technical: keep responsibility, provenance, and agency attached to the people inside a system, then build the structure that makes that durable."
        footer = foot(ID["legal"] + " · UEI TMUKBK9UY3H2 · EIN 39-2829761 · Kansas City, Missouri")
    else:
        summary = ("A systems operator whose career has run through emergency medicine, public health, military service, professional governance, and public-interest technology. Those look like domain changes. They aren’t — each was the same discipline applied at a different boundary: where an institution meets a person, a machine, an overseer, or itself. The rare principal who has worked at both the consequence end of that problem as a flight medic and at the structural end as an infrastructure builder, researcher, and governance designer. "
                   + N + " is the discipline of interfaces, named and practiced deliberately.")
        edu_l = ["**MPH** — Master of Public Health · Univ. of Kansas *(in progress)*",
                 "**MS** — Biomedical & Physical Sciences (Population Health) · Univ. of Kansas School of Medicine, 2025||Thesis: Policy Capacity in Governmental Public Health Agencies",
                 "**BA** — French Language & Culture · Univ. of Kansas, 2015",
                 "**BA** — Applied Behavioral Science: Community Health & Development · Univ. of Kansas, 2015"]
        edu_r = ["**Preclinical Medicine** — completed MD-curriculum preclinical education",
                 "**Instructorships** — AHA-certified ACLS · PALS · NRP · BLS *(training design & delivery, not just certification)*",
                 "**Security clearance** — Secret eligibility, favorably adjudicated *(access inactive)*"]
        exp = [("Public Health & Research", "Population-health researcher in policy capacity, workforce competency, and public-health systems. Master’s thesis reviewed how policy capacity is defined, measured, and governed across U.S. state and local health departments."),
               ("Clinical & Emergency Services", CLINICAL), ("Military Service", MILITARY),
               ("Professional Leadership & Governance", LEADERSHIP),
               ("Technology & Infrastructure", "Cloud-native infrastructure, automation, and identity-management systems; distributed systems, PKI, and security architecture. Sole author of a unique **hkdf-derive** (published, MIT) — concrete evidence of the security-architecture work."),
               ("AI & Systems Research", AIRES)]
        tech = "Static-first web · Data-pipeline & schema/export design · Multilingual content systems · Accessibility · Cloud-native infrastructure & automation · PKI / identity & trust · security architecture · AI-governance & agent-memory design · Usefully resilient architecture"
        record = "USCIS biometrics comments ×3 · NWK-408 comment · *Abstraction Harm* · *Situated Inference* · *The Gospel of Metrics* · Record Sufficiency Matrix"
        closing = "The through-line isn’t a technology or a sector. It’s the habit of asking where the interface is needed before asking what to build — recognizing that tools and systems suffer the same phenomenon at different boundaries."
        footer = foot(IDS_FULL)

    def edu(items):
        out = []
        for i in items:
            a, _, th = i.partition("||")
            out.append(f"<li>{fmt(a)}" + (f'<span class="th">{fmt(th)}</span>' if th else "") + "</li>")
        return '<ul class="sq tight">' + "".join(out) + "</ul>"

    ident = (f'<div class="bio-id"><div><h1>Brian J. London</h1><p class="role">{fmt(role)}</p></div>'
             '<div class="place">Kansas City, Missouri</div></div>')
    if solo:
        head = (f'<div class="cols" style="grid-template-columns:minmax(0,1fr) 3in"><header class="bio-mast">{lockup()}</header>'
                '<div class="doclabel"><div class="k">Principal · Key Personnel</div><div class="s">Capability &amp; experience of record</div></div></div>'
                f'<hr class="rule">{ident}')
    else:
        head = rh("Principal · Key Personnel", "Capability & experience of record") + ident
    exp_html = "".join(f"<h3>{fmt(h)}</h3><p>{fmt(p)}</p>" for h, p in exp)
    side = (panel("Technical Proficiencies", f"<p>{fmt(tech)}</p>") + panel("Specialized Areas", f"<p>{fmt(SPECIAL)}</p>")
            + panel("Public Record", f"<p>{fmt(record)}</p>") + contact_panel(ID["site"]))
    inner = (head + f'<p class="summary">{fmt(summary)}</p>'
             + sh("Education & Credentials") + f'<div class="edu">{edu(edu_l)}{edu(edu_r)}</div>'
             + sh("Experience & Domains")
             + f'<div class="bio-cols"><div class="exp">{exp_html}<div class="close"><p class="c">{fmt(closing)}</p>{thesis()}</div></div><aside>{side}</aside></div>')
    return page(inner, footer, "p-bio v-" + v)


# --------------------------------------------------------------------------
# Appendix — fifteen standard deliverable packages
# --------------------------------------------------------------------------
PK = [
 (1, "Public Resource Directory", "Package", "Fixed-scope build + retainer",
  "Build a searchable, confidence-tiered public directory of services for a defined population or jurisdiction.",
  ["Structured service inventory", "Searchable public directory", "Data dictionary", "CSV/JSON export", "Maintenance documentation"],
  ["Every listed service carries a confidence tier and a documented evidence basis", "Directory is searchable and filterable by the agreed categories",
   "Export validates against the published data dictionary with zero schema errors", "Maintenance documentation lets a third party run the correction workflow unassisted"]),
 (2, "Public-Facing Data Portal", "Package", "Fixed-scope build",
  "Stand up a machine-readable public data surface with documented schema and update cadence.",
  ["Data publication framework", "Metadata standards", "Downloadable datasets", "Provenance documentation", "Publishing procedures"],
  ["Datasets validate against the published metadata standard", "Every dataset traces to a documented source and transformation history",
   "Stated update cadence is met on the first scheduled cycle", "Publishing procedure is reproducible by agency staff without the original builder"]),
 (3, "Public Information Architecture", "Assessment", "Assessment / memorandum",
  "Assess how the public actually navigates an existing information surface, and where it fails them.",
  ["Navigation analysis", "User journey mapping", "Content inventory", "Accessibility review", "Improvement roadmap"],
  ["Navigation analysis names specific failure points, not general impressions", "Journey maps reflect real, representative user paths, not assumed ones",
   "Content inventory accounts for all in-scope content with nothing unclassified", "Roadmap items are individually scoped and sequenced, not a single undifferentiated list"]),
 (4, "Accessibility & Plain-Language", "Review", "Fixed-scope",
  "Audit a public-facing surface against accessibility standards and plain-language readability, and rewrite what fails.",
  ["Content audit", "Accessibility findings", "Plain-language revisions", "Style guidance", "Compliance recommendations"],
  ["Findings cite the specific standard and criterion violated (e.g., WCAG 2.1)", "Every flagged item ships with a remediation, not just a citation",
   "Revised content is rewritten to the agreed reading level, not merely flagged", "Style guidance is usable by agency staff for future content without further review"]),
 (5, "Community Resource Ecosystem", "Assessment", "Assessment / memorandum",
  "Map the actual landscape of services available to a population — including the gaps and dead referrals nobody admits to.",
  ["Service landscape analysis", "Gap identification", "Referral mapping", "Coordination recommendations", "Public report"],
  ["Landscape analysis is sourced to dated, verifiable evidence per the confidence-tier standard", "Identified gaps are specific to population, service type, and geography",
   "Referral paths are actually tested, not assumed functional", "Public report is publishable as delivered, not an internal draft"]),
 (6, "Record Sufficiency", "Review", "Fixed-scope memorandum",
  "Assess whether a system’s records let affected stakeholders understand, contest, and review a consequential decision.",
  ["Record sufficiency assessment", "Gap analysis", "Risk findings", "Remediation recommendations", "Executive summary"],
  ["Assessment is scored against every Record Sufficiency Matrix axis (traceability, provenance, attribution, notice, contestability, reviewability, retention)",
   "Every gap finding maps to a specific axis and a specific remediation", "Risk findings separate high-impact / insufficient-record cases from lower-stakes gaps",
   "Executive summary stands alone for a reviewer who reads nothing else"]),
 (7, "AI Governance", "Review", "Fixed-scope memorandum",
  "Assess an AI-mediated workflow’s risk profile, attribution clarity, and control points.",
  ["AI system inventory", "Risk assessment", "Governance framework", "Human-review controls", "Implementation guidance"],
  ["System inventory accounts for every AI-mediated decision or output point in scope", "Human- vs. AI-authored outputs are explicitly distinguished at every point identified",
   "Governance framework specifies named stop/halt conditions, not general principles", f"Implementation guidance is actionable by agency staff without a {N} hand-hold"]),
 (8, "Decision Traceability", "Framework", "Fixed-scope build",
  "Build the structure that lets any consequential decision be reconstructed and reviewed after the fact.",
  ["Decision-record template", "Responsibility mapping", "Documentation workflow", "Review procedures", "Governance guide"],
  ["Template captures inputs, reasoning, authorship, and outcome for every decision class in scope", "Each decision class names a specific accountable role, not a department",
   "A sample decision can be reconstructed end-to-end using only the records it produced", "Review procedure states who can initiate review and on what basis"]),
 (9, "Provenance & Data Lineage", "Assessment", "Fixed-scope memorandum",
  "Trace how data moves through a system and confirm nothing is silently losing its source.",
  ["Source inventory", "Data flow mapping", "Lineage documentation", "Integrity findings", "Governance recommendations"],
  ["Source inventory accounts for every system or feed providing data in scope", "Every output field traces to a named originating source — no orphaned fields",
   "Integrity findings flag every point where provenance is currently lost or unclear", "Recommendations are specific enough to implement without further scoping"]),
 (10, "Procurement Documentation Support", "Package", "Per-solicitation",
  "Assemble or review the documentation package a specific solicitation requires.",
  ["Statement of Work review", "Requirements analysis", "Evaluation support", "Traceability matrix", "Procurement record package"],
  ["SOW review surfaces every ambiguous or unscoped requirement before submission", "Traceability matrix maps every stated requirement to a response element, with no gaps",
   "Record package is submission-ready in the solicitation’s required format", "Evaluation support is usable by a non-author reviewer without further explanation"]),
 (11, "Public Comment & Regulatory Review", "Support", "Per-item",
  "Produce docket-ready public comment on a specific rulemaking or regulatory action.",
  ["Source review", "Evidence synthesis", "Draft comments", "Supporting appendices", "Citation package"],
  ["Every factual claim in the draft is cited to a verifiable, dated source", "Draft is formatted to the docket’s submission requirements",
   f"Citation package allows independent verification without contacting {N}", "Comment is filing-ready as delivered, not a discussion draft"]),
 (12, "Process Mapping & Documentation", "Package", "Fixed-scope",
  "Document how a process actually runs — including the workarounds nobody put in the manual.",
  ["Current-state process maps", "Decision points", "Stakeholder responsibilities", "Bottleneck analysis", "Future-state recommendations"],
  ["Current-state map is validated against direct observation or staff interview, not policy alone", "Every decision point names who decides and on what basis",
   "Bottleneck analysis identifies specific, named constraints, not general inefficiency", "Future-state recommendations are sequenced and individually scoped"]),
 (13, "Institutional Knowledge Preservation", "Package", "Fixed-scope build",
  "Get what’s in one person’s head onto paper before they leave and take it with them.",
  ["Knowledge inventory", "Documentation standards", "Operational playbooks", "Retention recommendations", "Transition materials"],
  ["Knowledge inventory is validated by the source-holder as complete for the scoped function", "Playbooks are usable by a new hire with no prior institutional context",
   "Retention recommendations specify duration and rationale per record class", "Transition materials are tested against an actual handoff scenario before delivery"]),
 (14, "Civic Information Modernization", "Assessment", "Assessment / memorandum",
  "Assess an aging civic information system and chart a realistic path off it.",
  ["Current-state assessment", "System inventory", "Stakeholder interviews", "Modernization roadmap", "Prioritized implementation plan"],
  ["System inventory includes informal/shadow systems found during the assessment", "Stakeholder interviews represent every affected role, not leadership alone",
   "Roadmap items are individually scoped, sequenced, and costed at a planning level", "Implementation plan distinguishes must-do from nice-to-have, with stated rationale"]),
 (15, "Public Records Organization", "Package", "Fixed-scope",
  "Turn a disorganized records holding into an indexed, audit-ready archive.",
  ["Record inventory", "Classification structure", "Retrieval framework", "Documentation standards", "Audit-ready archive design"],
  ["Record inventory accounts for the full scoped holding, with no unclassified residual", "Classification structure is applied consistently across the full inventory",
   "A named record can be located within the agreed retrieval-time standard", "An outside reviewer can locate and verify a sampled record without the original builder’s help"]),
]


def pk(n):
    num, t, typ, kind, blurb, dl, ac = PK[n - 1]
    return (f'<article class="pk"><div class="top"><h3><span class="n">{num}</span><span>{fmt(t)}<br>{fmt(typ)}</span></h3>'
            f'<span class="kind">{fmt(kind.upper())}</span></div><p class="blurb">{fmt(blurb)}</p>'
            '<div class="grid"><div><div class="lab">Deliverables</div><ul class="chk">'
            + "".join(f"<li>{fmt(d)}</li>" for d in dl)
            + '</ul></div><div><div class="lab">Acceptance Criteria</div>' + runin(ac) + "</div></div></article>")


def famhead(i, first=False):
    n, t, r, w, *_ = FAMS[i]
    st = ' style="border-top:0;padding-top:0"' if first else ""
    return (f'<header class="famhead"{st}><h2><span class="n">{n}</span><span>{fmt(t)}</span></h2>'
            f'<p class="rel">{fmt(r)}</p><p class="when">{fmt(w)}</p></header>')


def appendix_pages(paged):
    def slim():
        return (f'<header class="slim"><span class="l">{fmt(N)} · Service Catalog Appendix</span>'
                '<span class="r">Standard Deliverable Packages</span></header>')

    def f(i):
        return foot(IDS_FULL + (f" · Appendix page {i} of 4" if paged else ""))

    std = [("Fixed scope", "Agreed in writing before work begins."), ("Defined deliverables", "A named artifact list, not a vague engagement."),
           ("Visible acceptance criteria", "How “done” is judged — written down, shared up front."),
           ("Open & inspectable", "Machine-readable outputs; provenance preserved.")]
    idx = [("01", "Information Infrastructure", "Human <-> Institution", "5 packages"),
           ("02", "Governance & Accountability", "Institution <-> Oversight / Software", "6 packages"),
           ("03", "Institutional Operations", "Institution <-> Itself", "4 packages")]
    p5 = (rh("Service Catalog · Appendix", "Standard Deliverable Packages")
          + '<h1 class="pt">Standard Deliverable Packages</h1>'
          + f'<p class="intro">{fmt("The full specification behind the three-family Service Catalog: **fifteen packages**, each with a fixed scope, a named deliverable checklist, and visible acceptance criteria agreed before work begins. Each family is one region of the interface map. Any package can be scoped directly against a solicitation’s statement of work; none are sold as open-ended “consulting engagements.”")}</p>'
          + '<div class="ax-std">' + "".join(f'<div><div class="h">{fmt(h)}</div><p>{fmt(p)}</p></div>' for h, p in std) + "</div>"
          + '<div class="ax-idx">' + "".join(
              f'<div><div class="h"><span class="n">{n}</span>{fmt(t)}</div><div class="r">{fmt(r)} <span class="c">· {c}</span></div></div>'
              for n, t, r, c in idx) + "</div>"
          + famhead(0) + pk(1) + pk(2) + pk(3))
    p6 = slim() + pk(4) + pk(5) + famhead(1) + pk(6) + pk(7)
    p7 = slim() + pk(8) + pk(9) + pk(10) + pk(11)
    p8 = slim() + famhead(2, first=True) + pk(12) + pk(13) + pk(14) + pk(15)
    return [page(p, f(i), "p-appendix") for i, p in enumerate((p5, p6, p7, p8), 1)]


# --------------------------------------------------------------------------
def doc(title, pages):
    return ("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">"
            f"<title>{html.escape(title)}</title><link rel=\"stylesheet\" href=\"doc.css\"></head>\n"
            '<body class="mm">\n' + "\n".join(pages) + "\n</body></html>\n")


def packet(v):
    return [statement_page(v), catalog_page(), projects_page(), bio_page("packet")] + appendix_pages(paged=(v == "aug"))


DOCS = {
    "Means-Measures-Capability-Statement": (f"{N} — Capability Statement", [statement_page("solo")]),
    "Means-Measures-Principal-Bio": (f"{N} — Principal Bio", [bio_page("solo")]),
    "Means-Measures-Capability-Packet": (f"{N} — Capability Packet", packet("aug")),
    "MeansMeasuresCapabilityPacket": (f"{N} — Capability Packet", packet("jul")),
}

if __name__ == "__main__":
    here = pathlib.Path(__file__).parent
    for name, (title, pages) in DOCS.items():
        (here / f"{name}.html").write_text(doc(title, pages), encoding="utf-8")
        print("wrote", name + ".html", len(pages), "page(s)")
